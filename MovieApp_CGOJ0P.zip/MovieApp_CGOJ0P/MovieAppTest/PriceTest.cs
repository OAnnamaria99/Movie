using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MovieAppTest
{
    [TestClass]
    public class PriceTest //
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
